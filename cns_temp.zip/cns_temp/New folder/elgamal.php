<?php
// Database configuration
$host = 'localhost'; // Database host
$dbname = 'your_database_name'; // Database name
$username = 'your_username'; // Database username
$password = 'your_password'; // Database password

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);

    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully to the database!<br><br>";

    // Function to insert a new student
    function insertStudent($name) {
        global $pdo; // Use the global PDO instance
        $stmt = $pdo->prepare("INSERT INTO students (name) VALUES (:name)");
        $stmt->bindParam(':name', $name);
        $stmt->execute();
        echo "New student '$name' inserted successfully!<br>";
    }

    // Function to retrieve all students
    function getAllStudents() {
        global $pdo; // Use the global PDO instance
        $stmt = $pdo->query("SELECT * FROM students");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Insert a new student (for demonstration purposes)
    insertStudent("John Doe");
    insertStudent("Jane Smith");

    // Retrieve all students
    $students = getAllStudents();

    // Display the results
    echo "<h3>Student List:</h3>";
    foreach ($students as $student) {
        echo "ID: " . $student['id'] . " - Name: " . $student['name'] . "<br>";
    }

} catch (PDOException $e) {
    // Handle connection errors
    echo "Connection failed: " . $e->getMessage();
}
?>
