<?php
// Database configuration
$host = 'localhost'; // Change as necessary
$db = 'cns';
$user = 'root'; // Change as necessary
$pass = ''; // Change as necessary

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Include the ElGamal functions
function isPrime($num) {
    if ($num <= 1) return false;
    for ($i = 2; $i <= sqrt($num); $i++) {
        if ($num % $i == 0) return false;
    }
    return true;
}

function generateLargePrime($bits = 16) {
    while (true) {
        $p = random_int((1 << ($bits - 1)), (1 << $bits) - 1);
        if (isPrime($p)) {
            return $p;
        }
    }
}

function modInverse($a, $p) {
    return bcpowmod($a, $p - 2, $p);
}

function generateKeys() {
    $p = generateLargePrime();
    $g = random_int(2, $p - 1); // generator
    $x = random_int(1, $p - 2); // private key
    $y = bcpowmod($g, $x, $p); // public key
    return [[$p, $g, $y], $x]; // public and private keys
}

function decrypt($privateKey, $ciphertext, $publicKey) {
    list($p, ,) = $publicKey;
    list($c1, $c2) = $ciphertext;
    $s = bcpowmod($c1, $privateKey, $p); // shared secret
    $sInv = modInverse($s, $p); // modular inverse
    $message = bcmul($c2, $sInv) % $p; // recover the message
    return $message;
}

// Fetch all records
$result = $conn->query("SELECT * FROM records");

// Get the public/private keys from the last insertion for decryption
$stmt = $conn->prepare("SELECT encrypted_c1, encrypted_c2 FROM records ORDER BY id DESC LIMIT 1");
$stmt->execute();
$stmt->bind_result($c1, $c2);
$stmt->fetch();
$stmt->close();

$publicKey = generateKeys()[0]; // Generate a new public key for decryption
$privateKey = random_int(1, $publicKey[0] - 2); // For decryption, a temporary private key

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student Records</title>
</head>
<body>
    <h1>Stored Student Records</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Encrypted C1</th>
                <th>Encrypted C2</th>
                <th>Decrypted Record</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = $result->fetch_assoc()) {
                $ciphertext = [$row['encrypted_c1'], $row['encrypted_c2']];
                $decryptedRecord = decrypt($privateKey, $ciphertext, $publicKey);
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['encrypted_c1']}</td>
                        <td>{$row['encrypted_c2']}</td>
                        <td>$decryptedRecord</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
    <br>
    <a href="index.php">Go Back</a>
</body>
</html>

<?php
$conn->close();
?>
